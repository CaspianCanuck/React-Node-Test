﻿import * as React from "react";
import { render } from "react-dom";
import UploadsContainer from "./components/uploads-container";

render(<UploadsContainer />, document.getElementById('root'))
