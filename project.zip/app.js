"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var React = require("react");
var react_dom_1 = require("react-dom");
var uploads_container_1 = require("./components/uploads-container");
react_dom_1.render(React.createElement(uploads_container_1.default, null), document.getElementById('root'));
//# sourceMappingURL=app.js.map